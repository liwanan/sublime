class Main {
	public static void main(String[] args) {
		//get_settings
	}

}